from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Prescription

@csrf_exempt
def upload_prescription(request):
    if request.method == 'POST' and request.FILES.get('file'):
        uploaded_file = request.FILES['file']
        prescription = Prescription.objects.create(file=uploaded_file)
        return JsonResponse({'message': 'File uploaded successfully!', 'file_url': prescription.file.url})
    return JsonResponse({'error': 'Invalid request or no file uploaded.'}, status=400)
