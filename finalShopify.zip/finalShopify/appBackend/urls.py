from django.urls import path
from .views import upload_prescription

urlpatterns = [
    path('upload/', upload_prescription, name='upload_prescription'),
]