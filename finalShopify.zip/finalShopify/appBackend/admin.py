from django.contrib import admin

# Register your models here.
from .models import Prescription

@admin.register(Prescription)
class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ('id', 'file', 'uploaded_at')  # Fields to display in the admin list view
    search_fields = ('uploaded_at',)             # Enable search functionality
    list_filter = ('uploaded_at',)         