from django.db import models

class Prescription(models.Model):
    # Define the fields for the Prescription model
    file = models.FileField(upload_to='uploads/prescriptions/')  # Directory where files will be saved
    uploaded_at = models.DateTimeField(auto_now_add=True)        # Timestamp for when the file was uploaded

    def __str__(self):
        # Return a string representation of the model
        return f"Prescription uploaded at {self.uploaded_at}"
