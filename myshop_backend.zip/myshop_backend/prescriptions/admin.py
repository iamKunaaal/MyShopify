from django.contrib import admin
from .models import Prescription


admin.site.register(Prescription) 

class PrescriptionAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'code', 'approved', 'uploaded_at')  # Display fields in admin panel
    actions = ['approve_prescription']  # Custom action

    def approve_prescription(self, request, queryset):
        queryset.update(approved=True)  # Mark the prescription as approved
        for prescription in queryset:
            prescription.generate_code()  # Generate the 6-digit code
            # Sending approval email with the 6-digit code
            send_mail(
                'Prescription Approved',
                f'Hi {prescription.name}, your prescription has been approved. Here is your 6-digit code: {prescription.code}',
                'your_email@example.com',  # Sender's email
                [prescription.email],  # Recipient email
                fail_silently=False,
            )
