from django.db import models
import random
import string

def generate_code():
    length = 6
    digits = string.digits  # String of digits (0-9)
    random_code = ''.join(random.choice(digits) for _ in range(length))
    return random_code

class Prescription(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    prescription_file = models.FileField(upload_to='prescriptions/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    code = models.CharField(max_length=6, blank=True, null=True)  # New field to store 6-digit code
    approved = models.BooleanField(default=False)  # New field to store approval status

    def save(self, *args, **kwargs):
        if not self.code:  # If code is not already set
            self.code = generate_code()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name
