from django.shortcuts import render
import random
import string
from django.http import JsonResponse
from .models import Prescription
from django.shortcuts import get_object_or_404
from django.http import HttpResponse, JsonResponse


def upload_prescription(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        prescription_file = request.FILES.get('prescription')

        # Save Prescription
        Prescription.objects.create(
            name=name,
            email=email,
            prescription_file=prescription_file
        )
        return JsonResponse({'message': 'Prescription uploaded successfully!'}, status=200)

    return JsonResponse({'error': 'Invalid request'}, status=400)



# Logic for upload code

def upload_code(request):
    if request.method == 'POST':
        user_code = request.POST.get('code', '').strip()  # Get the code from POST request

        if not user_code:  # Check if code is empty
            return HttpResponse('<h1>Code cannot be empty!</h1>')

        # Attempt to fetch the Prescription using the provided code
        try:
            prescription = Prescription.objects.get(code=user_code)
            
            # Check if prescription is already approved
            if prescription.approved:
                return HttpResponse('<h1>Product unlocked successfully! You can now purchase the product.</h1>')
            else:
                return HttpResponse('<h1>This code has not been approved yet. Please wait for admin approval.</h1>')

        except Prescription.DoesNotExist:
            return HttpResponse('<h1>Invalid code! Please try again.</h1>')

    else:
        return HttpResponse('<h1>Invalid request method.</h1>')

# Admin side approval function
def approve_prescription(request, prescription_id):
    if not request.user.is_staff:  # Ensure only admin can approve
        return HttpResponse('<h1>Unauthorized access!</h1>')
        
    try:
        prescription = Prescription.objects.get(id=prescription_id)
        prescription.approved = True
        prescription.save()
        return HttpResponse('<h1>Prescription approved successfully!</h1>')
    except Prescription.DoesNotExist:
        return HttpResponse('<h1>Prescription not found!</h1>')