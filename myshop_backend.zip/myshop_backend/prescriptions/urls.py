from django.urls import path
from .views import upload_prescription, upload_code

urlpatterns = [
    path('upload-prescription/', view=upload_prescription, name='upload_prescription'),
    path('upload-code/', view=upload_code, name='upload_code'),
]